#!/usr/bin/env bash
# SPDX-FileCopyrightText: 2026 Chris Sutton
# SPDX-License-Identifier: MIT
# Local-only KnetSentry acceptance runner, M8.1 — comprehensive SOC dashboard. Never run the entire script as root.
set -uo pipefail
umask 077
cd -- "$(dirname -- "${BASH_SOURCE[0]}")" || exit 2
root=$(pwd -P)
if (( EUID == 0 )); then echo 'Run as your ordinary development user, not root.' >&2; exit 2; fi
if [[ $(git rev-parse --show-toplevel 2>/dev/null) != "$root" || ! -f CMakePresets.json ]]; then
    echo 'Place this script in the KnetSentry Git repository root.' >&2; exit 2
fi
live=0
core_only=0
topology_namespace=0
firewall_namespace=0
network_fixture=0
storage_mount_fixture=0
for arg in "$@"; do
    case "$arg" in
        --systemd) live=1 ;;
        --core-only) core_only=1 ;;
        --topology-namespace) topology_namespace=1 ;;
        --firewall-namespace) firewall_namespace=1 ;;
        --network-fixture) network_fixture=1 ;;
        --storage-mount-fixture) storage_mount_fixture=1 ;;
        --help) echo 'Usage: bash run_local_acceptance.sh [--systemd] [--core-only] [--topology-namespace] [--firewall-namespace] [--network-fixture] [--storage-mount-fixture]'; exit 0 ;;
        *) echo "Unknown option: $arg" >&2; exit 2 ;;
    esac
done
if (( topology_namespace && core_only )); then echo '--topology-namespace requires the full Release build.' >&2; exit 2; fi
if (( firewall_namespace && core_only )); then echo '--firewall-namespace requires the full acceptance workflow.' >&2; exit 2; fi
if (( network_fixture && core_only )); then echo '--network-fixture requires the full acceptance workflow.' >&2; exit 2; fi
if (( storage_mount_fixture && core_only )); then echo '--storage-mount-fixture requires full acceptance.' >&2; exit 2; fi
if (( live && core_only )); then echo '--systemd requires the full Release build.' >&2; exit 2; fi
# Never hide a tracked file or overwrite a tracked report.
for path in run_local_acceptance.sh local_acceptance_results.log; do
    if git ls-files --error-unmatch -- "$path" >/dev/null 2>&1; then
        echo "Refusing: $path is tracked. Keep local acceptance artifacts untracked." >&2; exit 2
    fi
done
exclude=$(git rev-parse --git-path info/exclude) || exit 2
mkdir -p -- "$(dirname -- "$exclude")" || exit 2
touch -- "$exclude" || exit 2
for pattern in /run_local_acceptance.sh /local_acceptance_results.log '/.local_acceptance_results.*'; do
    if ! grep -Fxq -- "$pattern" "$exclude"; then printf '\n%s\n' "$pattern" >> "$exclude" || exit 2; fi
done
report="$root/local_acceptance_results.log"
temp=$(mktemp "$root/.local_acceptance_results.XXXXXXXX") || exit 2
# Rename rather than follow an existing symlink. A partial run is retained on interruption.
finalize() {
    if [[ -f "$temp" ]]; then
        mv -fT -- "$temp" "$report" || { echo "Report retained at $temp" >&2; return 1; }
    fi
}
trap finalize EXIT
trap 'exit 130' INT
trap 'exit 143' TERM

run_all() {
    local failures=0 passes=0 skipped=0 blocked=0 preset script release_built=0 release_ready=0
    local -a presets=(linux-release linux-debug linux-sanitize linux-clazy linux-analysis linux-core-only linux-sanitize-core-only)
    if (( core_only )); then presets=(linux-core-only linux-sanitize-core-only); fi
    run() {
        local label=$1 rc; shift
        printf '\n===== %s =====\n' "$label"
        printf '+ '; printf '%q ' "$@"; printf '\n'
        "$@"; rc=$?
        if (( rc == 0 )); then printf 'RESULT: PASS — %s\n' "$label"; ((passes+=1)); return 0; fi
        printf 'RESULT: FAIL (%d) — %s\n' "$rc" "$label"; ((failures+=1)); return 1
    }
    # Exit 77 is meaningful only for this explicitly optional test. All
    # other checks keep the existing strict nonzero-exit failure behavior.
    run_topology_namespace() {
        local label='M3.3 isolated network namespace changes (explicit request)' rc
        local -a command=(python3 -B scripts/check_m33_topology_namespace.py --binary build/presets/linux-release/tests/knetsentry_network_topology_test)
        printf '\n===== %s =====\n' "$label"
        printf '+ '; printf '%q ' "${command[@]}"; printf '\n'
        "${command[@]}"; rc=$?
        case "$rc" in
            0) printf 'RESULT: PASS — %s\n' "$label"; ((passes+=1)) ;;
            77) printf 'RESULT: BLOCKED (77) — %s\n' "$label"; ((blocked+=1)) ;;
            *) printf 'RESULT: FAIL (%d) — %s\n' "$rc" "$label"; ((failures+=1)) ;;
        esac
        return 0
    }
    skip() { printf '\nRESULT: SKIPPED — %s\n' "$1"; ((skipped+=1)); }
    printf 'KnetSentry local acceptance — M8.1 — comprehensive SOC dashboard\nUTC start: %s\n' "$(date -u +%FT%TZ)"
    printf 'Revision: '; git rev-parse HEAD
    git status --short
    printf 'Inherited test umask: '; umask
    printf 'Kernel: '; uname -srmo
    cmake --version; c++ --version | head -n 1
    # Authentication is explicit, never read from the report pipeline or stored.
    # No background sudo keepalive; refresh before each privileged operation.
    authenticate() {
        printf 'Administrator authentication required: %s\n' "$1"
        if [[ ! -t 0 && ! -r /dev/tty ]]; then
            echo 'No interactive terminal for sudo authentication.'; return 1
        fi
        sudo -v </dev/tty
    }
    # Report only known fixture artifact names, not the host inventory.
    fixture_snapshot() {
        local links tables
        links=$(/usr/sbin/ip -j link show | python3 -c 'import json,sys; print(" ".join(sorted(x["ifname"] for x in json.load(sys.stdin) if x["ifname"] in {"ks33a","ks33b","ks36a","ks36b"})))') || return 1
        tables=$(sudo -n /usr/sbin/nft -j list tables | python3 -c 'import json,sys; print(" ".join(sorted(x["table"]["name"] for x in json.load(sys.stdin)["nftables"] if "table" in x and x["table"]["name"] in {"knetsentry_m35","knetsentry_m35_test_unrelated","knetsentry_m36_test"})))') || return 1
        printf 'links=%s;tables=%s' "$links" "$tables"
    }
    privileged_step() {
        local label=$1 check_fixture=$2 before after rc=0; shift 2
        authenticate "$label" || return 1
        if (( check_fixture )); then
            before=$(fixture_snapshot) || return 1
            if [[ $before != 'links=;tables=' && $before != 'links=;tables=knetsentry_m35' ]]; then
                echo 'Unexpected fixture artifacts already present; refusing privileged test.'; return 1
            fi
        fi
        printf 'PRIVILEGED BEGIN: %s\n' "$label"
        printf '+ sudo -n '; printf '%q ' "$@"; printf '\n'
        sudo -n "$@" || rc=$?
        printf 'PRIVILEGED END: %s (exit %d)\n' "$label" "$rc"
        if (( check_fixture )); then
            after=$(fixture_snapshot) || { echo 'Fixture cleanup inspection unavailable'; return 1; }
            if [[ $before != "$after" ]]; then
                echo 'Fixture cleanup postcondition: FAIL (known host artifacts changed)'; return 1
            fi
            echo 'Fixture cleanup postcondition: PASS (known host artifacts unchanged)'
        fi
        return "$rc"
    }
    if (( live || firewall_namespace || network_fixture || storage_mount_fixture )); then
        if ! run 'Administrator authentication preflight' authenticate 'requested privileged checks'; then
            printf '\n===== SUMMARY =====\nPASS=0 FAIL=1 SKIPPED=0 BLOCKED=0\nOVERALL: FAIL — authentication preflight\n'
            return 1
        fi
    fi
    for preset in "${presets[@]}"; do
        if run "$preset configure" cmake --preset "$preset" --fresh &&
           run "$preset build" cmake --build --preset "$preset" --parallel "${KNETSENTRY_BUILD_JOBS:-4}"; then
            if [[ $preset == linux-release ]]; then release_built=1; fi
            if run "$preset CTest" ctest --preset "$preset" --output-on-failure --parallel 1; then
                if [[ $preset == linux-release ]]; then release_ready=1; fi
            fi
        else
            skip "$preset dependent build/tests (configuration or compilation failed)"
        fi
    done
    for script in scripts/verify_m*.py; do run "source verifier $script" python3 "$script"; done
    run 'official REUSE lint' reuse lint
    run 'CI and source formatting' python3 scripts/verify_m18_ci.py --format
    run 'M5.2 systemd package versions' dpkg-query -W '-f=${Package} ${Version}\n' libsystemd-dev libsystemd0 pkg-config
    run 'M6.4 SQLite package versions' dpkg-query -W '-f=${Package} ${Version}\n' libsqlite3-dev libsqlite3-0
    run 'M4.2 OpenSSL package versions' dpkg-query -W '-f=${Package} ${Version}\n' libssl-dev libssl3t64
    run 'M2.7 systemd parser (no installation)' python3 scripts/verify_m27_systemd.py --systemd-parser
    run 'Git whitespace check' git diff --check
    run 'Git staged whitespace check' git diff --cached --check
    if (( release_built )); then
        run 'M4.2 identity contract (verbose)' ctest --preset linux-release -R '^knetsentry_identity_contract$' --verbose --no-tests=error
        run 'M4.8 authentication and transport security (verbose)' ctest --preset linux-release -R '^knetsentry_authentication_transport_regression$' --verbose --no-tests=error
        run 'M5.2 journal collection (verbose)' ctest --preset linux-release -R '^knetsentry_journal_collection_contract$' --verbose --no-tests=error
        run 'M5.3 authentication collection (verbose)' ctest --preset linux-release -R '^knetsentry_authentication_collection_contract$' --verbose --no-tests=error
        run 'M5.4 audit collection (verbose)' ctest --preset linux-release -R '^knetsentry_audit_collection_contract$' --verbose --no-tests=error
        run 'M5.5 telemetry delivery (verbose)' ctest --preset linux-release -R '^knetsentry_telemetry_delivery_contract$' --verbose --no-tests=error
        run 'M5.6 file integrity monitoring (verbose)' ctest --preset linux-release -R '^knetsentry_file_integrity_contract$' --verbose --no-tests=error
        run 'M5.7 privacy policy (verbose)' ctest --preset linux-release -R '^knetsentry_privacy_policy_contract$' --verbose --no-tests=error
        run 'M6.1 event ingestion (verbose)' ctest --preset linux-release -R '^knetsentry_event_ingestion_contract$' --verbose --no-tests=error
        run 'M6.2 event normalization (verbose)' ctest --preset linux-release -R '^knetsentry_event_normalization_contract$' --verbose --no-tests=error
        run 'M6.4 SQLite storage (verbose)' ctest --preset linux-release -R '^knetsentry_sqlite_storage_contract$' --verbose --no-tests=error
        run 'M6.5 original evidence integrity (verbose)' ctest --preset linux-release -R '^knetsentry_evidence_integrity_contract$' --verbose --no-tests=error
        run 'M6.6 event search and filtering (verbose)' ctest --preset linux-release -R '^knetsentry_event_search_contract$' --verbose --no-tests=error
        run 'M6.10 split storage (verbose)' ctest --preset linux-release -R '^knetsentry_split_storage_contract$' --verbose --no-tests=error
        run 'M7.1 deterministic detection (verbose)' ctest --preset linux-release -R '^knetsentry_detection_contract$' --verbose --no-tests=error
        run 'M7.2 rule schema validation (verbose)' ctest --preset linux-release -R '^knetsentry_rule_schema_contract$' --verbose --no-tests=error
        run 'M7.3 authentication patterns (verbose)' ctest --preset linux-release -R '^knetsentry_authentication_patterns_contract$' --verbose --no-tests=error
        run 'M7.4 system integrity (verbose)' ctest --preset linux-release -R '^knetsentry_system_integrity_contract$' --verbose --no-tests=error
        run 'M7.5 rule scheduling (verbose)' ctest --preset linux-release -R '^knetsentry_scheduler_contract$' --verbose --no-tests=error
        run 'M7.6 alert lifecycle (verbose)' ctest --preset linux-release -R '^knetsentry_alerts_contract$' --verbose --no-tests=error
        run 'M7.8 composed detection recovery (verbose)' ctest --preset linux-release -R '^knetsentry_detection_recovery_contract$' --verbose --no-tests=error
        run 'M7.9 technique mappings (verbose)' ctest --preset linux-release -R '^knetsentry_technique_mappings_contract$' --verbose --no-tests=error
        run 'M8.1 dashboard summaries and rendered runtime (verbose)' ctest --preset linux-release -R '^knetsentry_(dashboard_summary_contract|gui_dashboard_runtime)$' --verbose --no-tests=error
        run 'M7.7 alert interface (verbose)' ctest --preset linux-release -R '^knetsentry_(gui_)?alert_interface_' --verbose --no-tests=error
        run 'M6.9 ingestion and storage recovery (verbose)' ctest --preset linux-release -R '^knetsentry_(storage_recovery_contract|ingestion_recovery_contract)$' --verbose --no-tests=error
        run 'M6.8 event explorer (verbose)' ctest --preset linux-release -R '^knetsentry_(event_explorer_contract|event_explorer_runtime|gui_event_explorer_runtime)$' --verbose --no-tests=error
        run 'M6.7 retention and storage quotas (verbose)' ctest --preset linux-release -R '^knetsentry_storage_retention_contract$' --verbose --no-tests=error
        run 'M6.3 event storage abstraction (verbose)' ctest --preset linux-release -R '^knetsentry_event_storage_contract$' --verbose --no-tests=error
        run 'M5.9 local telemetry status (verbose)' ctest --preset linux-release -R '^knetsentry_(telemetry_status_contract|telemetry_status_runtime|qt_health_model|gui_telemetry_runtime)$' --verbose --no-tests=error
        run 'M5.8 collector failure recovery (verbose)' ctest --preset linux-release -R '^knetsentry_collector_recovery_contract$' --verbose --no-tests=error
        run 'M5.1 endpoint-agent lifecycle and process (verbose)' ctest --preset linux-release -R '^knetsentry_agent_(lifecycle_contract|service_runtime)$' --verbose --no-tests=error
        run 'M4.7 agent roster (verbose)' ctest --preset linux-release -R '^knetsentry_agent_roster_(contract|runtime)$' --verbose --no-tests=error
        run 'M4.6 agent health (verbose)' ctest --preset linux-release -R '^knetsentry_agent_health_contract$' --verbose --no-tests=error
        run 'M4.5 credential lifecycle (verbose)' ctest --preset linux-release -R '^knetsentry_credential_lifecycle$' --verbose --no-tests=error
        run 'M4.4 enrollment contracts (verbose)' ctest --preset linux-release -R '^knetsentry_enrollment_(contract|admin)$' --verbose --no-tests=error
        run 'M4.3 mutual TLS contract (verbose)' ctest --preset linux-release -R '^knetsentry_tls_contract$' --verbose --no-tests=error
        run 'M4.1 agent protocol contract (verbose)' ctest --preset linux-release -R '^knetsentry_agent_protocol_contract$' --verbose --no-tests=error
        run 'Release binary hardening' python3 scripts/verify_m12_hardening.py --build-dir build/presets/linux-release
        run 'Release configured test inventory' python3 scripts/verify_m17_suites.py --build-dir build/presets/linux-release
        run 'M2.8 lifecycle IPC integration (verbose scenario evidence)' python3 scripts/verify_m28_lifecycle_ipc.py --build-dir build/presets/linux-release
        run 'M3.1 network scope policy (verbose)' python3 scripts/verify_m31_network_scope.py --build-dir build/presets/linux-release
        run 'M3.2 network prefix validation (verbose)' python3 scripts/verify_m32_network_prefix.py --build-dir build/presets/linux-release
        run 'M3.3 network topology awareness (verbose)' python3 scripts/verify_m33_network_topology.py --build-dir build/presets/linux-release
        run 'M3.4 fail-closed network authorization (verbose)' python3 scripts/verify_m34_network_authorization.py --build-dir build/presets/linux-release
        run 'M3.5 firewall profile contract (verbose)' ctest --preset linux-release -R '^knetsentry_firewall_profile_contract$' --verbose --no-tests=error
        if (( firewall_namespace )); then
            if (( release_ready && failures == 0 )); then
                run 'M3.5 isolated firewall enforcement (explicit administrator test)' privileged_step 'M3.5 firewall namespace' 1 /usr/bin/python3 -I -B scripts/firewall_m35.py live-isolated
            else
                skip 'M3.5 isolated firewall enforcement (prior required checks failed)'
            fi
        fi
        run 'M3.6 network isolation fixture (verbose)' ctest --preset linux-release -R '^knetsentry_network_isolation_fixture$' --verbose --no-tests=error
        run 'M3.7 adversarial network boundary (verbose)' ctest --preset linux-release -R '^knetsentry_network_adversarial_boundary$' --verbose --no-tests=error
        if (( network_fixture )); then
            if (( release_ready && failures == 0 )); then
                run 'M3.6/M3.7 isolated network policy fixture (explicit administrator test)' privileged_step 'M3.6/M3.7 network fixture' 1 /usr/bin/python3 -I -B scripts/network_fixture_m36.py --binary build/presets/linux-release/tests/knetsentry_network_isolation_test
            else
                skip 'M3.6/M3.7 isolated network policy fixture (prior required checks failed)'
            fi
        fi
        if (( storage_mount_fixture )); then
            if (( release_ready && failures == 0 )); then
                run 'M6.10 private mount detach and replacement (explicit administrator test)' privileged_step 'M6.10 storage mount fixture' 0 build/presets/linux-release/tests/knetsentry_split_storage_test --mount-fixture
            else
                skip 'M6.10 private mount fixture (prior required checks failed)'
            fi
        else
            skip 'M6.10 actual mount qualification (requires --storage-mount-fixture)'
        fi
        if (( topology_namespace )); then
            if (( release_ready )); then
                run_topology_namespace
            else
                skip 'M3.3 isolated namespace (Release CTest failed)'
            fi
        else
            echo 'Optional M3.3 isolated namespace qualification: NOT REQUESTED'
        fi
        run 'M2.9 toolbar lifecycle controls (verbose)' python3 scripts/verify_m29_daemon_toolbar.py --build-dir build/presets/linux-release
        run 'M3.8 read-only model and Settings navigation (verbose)' python3 scripts/verify_m38_desktop_scope.py --build-dir build/presets/linux-release
        run 'Actual GUI manager lifecycle and M3.8 scope inspection (automated multi-process)' ctest --preset linux-release -R '^knetsentry_gui_health_runtime$' --verbose --no-tests=error
        run 'QML static analysis (strict diagnostic gate)' python3 scripts/check_qml_lint.py
        if (( live && release_ready && failures == 0 )); then
            echo 'Live systemd requires the installed binary to match the fresh Release build; see docs/development/SYSTEMD_SERVICE_M27.md. No automatic installation is performed.'
            run 'Installed systemd runtime (explicit administrator test)' privileged_step 'M2.7 installed systemd runtime' 0 /usr/bin/python3 -B scripts/check_m27_systemd_runtime.py --binary build/presets/linux-release/apps/manager/knetsentryd --outsider "$(id -un)"
        elif (( live )); then
            skip 'Live systemd confinement (prior required checks failed; no service activation)'
        else
            skip 'Live systemd confinement (requires installed unit and --systemd)'
        fi
    else
        skip 'Release-only hardening, inventory, lifecycle, topology, QML, GUI and installed systemd checks (Release not built)'
    fi
    printf '\n===== SUMMARY =====\nPASS=%d FAIL=%d SKIPPED=%d BLOCKED=%d\n' "$passes" "$failures" "$skipped" "$blocked"
    printf 'UTC finish: %s\n' "$(date -u +%FT%TZ)"
    if (( failures )); then echo 'OVERALL: FAIL'; return 1; fi
    if (( blocked )); then echo 'OVERALL: PARTIAL — optional namespace qualification blocked; not a passing live-change test'; return 77; fi
    if (( ! firewall_namespace )); then echo 'M3.5 live firewall qualification: NOT REQUESTED (source/build checks only)'; fi
    if (( ! network_fixture )); then echo 'M3.6/M3.7 live network fixture qualification: NOT REQUESTED (source/build checks only)'; fi
    if (( skipped || core_only )); then echo 'OVERALL: PARTIAL — skipped checks are not qualified'; return 0; fi
    echo 'OVERALL: PASS — automated local checks only; visual review and hosted CI remain separate'
    return 0
}
run_all 2>&1 | tee "$temp"
status=("${PIPESTATUS[@]}")
if ! finalize; then exit 2; fi
trap - EXIT
printf '\nReport: %s\n' "$report"
if (( status[1] != 0 )); then exit 2; fi
exit "${status[0]}"
