#!/usr/bin/env bash
# SPDX-FileCopyrightText: 2026 Chris Sutton
# SPDX-License-Identifier: MIT
# Local-only KnetSentry acceptance runner, M2.8. Never run the entire script as root.
set -uo pipefail
umask 077
cd -- "$(dirname -- "${BASH_SOURCE[0]}")" || exit 2
root=$(pwd -P)
if (( EUID == 0 )); then echo 'Run as your ordinary development user, not root.' >&2; exit 2; fi
if [[ $(git rev-parse --show-toplevel 2>/dev/null) != "$root" || ! -f CMakePresets.json ]]; then
    echo 'Place this script in the KnetSentry Git repository root.' >&2; exit 2
fi
live=0
core_only=0
for arg in "$@"; do
    case "$arg" in
        --systemd) live=1 ;;
        --core-only) core_only=1 ;;
        --help) echo 'Usage: bash run_local_acceptance.sh [--systemd] [--core-only]'; exit 0 ;;
        *) echo "Unknown option: $arg" >&2; exit 2 ;;
    esac
done
if (( live && core_only )); then echo '--systemd requires the full Release build.' >&2; exit 2; fi
# Never hide a tracked file or overwrite a tracked report.
for path in run_local_acceptance.sh local_acceptance_results.log; do
    if git ls-files --error-unmatch -- "$path" >/dev/null 2>&1; then
        echo "Refusing: $path is tracked. Keep local acceptance artifacts untracked." >&2; exit 2
    fi
done
exclude=$(git rev-parse --git-path info/exclude) || exit 2
mkdir -p -- "$(dirname -- "$exclude")" || exit 2
touch -- "$exclude" || exit 2
for pattern in /run_local_acceptance.sh /local_acceptance_results.log '/.local_acceptance_results.*'; do
    if ! grep -Fxq -- "$pattern" "$exclude"; then printf '\n%s\n' "$pattern" >> "$exclude" || exit 2; fi
done
report="$root/local_acceptance_results.log"
temp=$(mktemp "$root/.local_acceptance_results.XXXXXXXX") || exit 2
# Rename rather than follow an existing symlink. A partial run is retained on interruption.
finalize() {
    if [[ -f "$temp" ]]; then
        mv -fT -- "$temp" "$report" || { echo "Report retained at $temp" >&2; return 1; }
    fi
}
trap finalize EXIT
trap 'exit 130' INT
trap 'exit 143' TERM

run_all() {
    local failures=0 passes=0 skipped=0 preset script release_built=0 release_ready=0
    local -a presets=(linux-release linux-debug linux-sanitize linux-clazy linux-analysis linux-core-only linux-sanitize-core-only)
    if (( core_only )); then presets=(linux-core-only linux-sanitize-core-only); fi
    run() {
        local label=$1 rc; shift
        printf '\n===== %s =====\n' "$label"
        printf '+ '; printf '%q ' "$@"; printf '\n'
        "$@"; rc=$?
        if (( rc == 0 )); then printf 'RESULT: PASS — %s\n' "$label"; ((passes+=1)); return 0; fi
        printf 'RESULT: FAIL (%d) — %s\n' "$rc" "$label"; ((failures+=1)); return 1
    }
    skip() { printf '\nRESULT: SKIPPED — %s\n' "$1"; ((skipped+=1)); }
    printf 'KnetSentry local acceptance — M2.8\nUTC start: %s\n' "$(date -u +%FT%TZ)"
    printf 'Revision: '; git rev-parse HEAD
    git status --short
    printf 'Inherited test umask: '; umask
    printf 'Kernel: '; uname -srmo
    cmake --version; c++ --version | head -n 1
    for preset in "${presets[@]}"; do
        if run "$preset configure" cmake --preset "$preset" --fresh &&
           run "$preset build" cmake --build --preset "$preset" --parallel "${KNETSENTRY_BUILD_JOBS:-4}"; then
            if [[ $preset == linux-release ]]; then release_built=1; fi
            if run "$preset CTest" ctest --preset "$preset" --output-on-failure --parallel 1; then
                if [[ $preset == linux-release ]]; then release_ready=1; fi
            fi
        else
            skip "$preset dependent build/tests (configuration or compilation failed)"
        fi
    done
    for script in scripts/verify_m*.py; do run "source verifier $script" python3 "$script"; done
    run 'official REUSE lint' reuse lint
    run 'CI and source formatting' python3 scripts/verify_m18_ci.py --format
    run 'M2.7 systemd parser (no installation)' python3 scripts/verify_m27_systemd.py --systemd-parser
    run 'Git whitespace check' git diff --check
    run 'Git staged whitespace check' git diff --cached --check
    if (( release_built )); then
        run 'Release binary hardening' python3 scripts/verify_m12_hardening.py --build-dir build/presets/linux-release
        run 'Release configured test inventory' python3 scripts/verify_m17_suites.py --build-dir build/presets/linux-release
        run 'M2.8 lifecycle IPC integration (verbose scenario evidence)' python3 scripts/verify_m28_lifecycle_ipc.py --build-dir build/presets/linux-release
        run 'Actual GUI manager lifecycle (automated multi-process)' ctest --preset linux-release -R '^knetsentry_gui_health_runtime$' --verbose --no-tests=error
        run 'QML static analysis (review warnings even on exit 0)' cmake --build --preset linux-release --target knetsentry_qmllint
        if (( live && release_ready )); then
            run 'Installed systemd runtime (explicit administrator test)' sudo /usr/bin/python3 -B scripts/check_m27_systemd_runtime.py --binary build/presets/linux-release/apps/manager/knetsentryd --outsider "$(id -un)"
        elif (( live )); then
            skip 'Live systemd confinement (Release CTest failed; no service activation)'
        else
            skip 'Live systemd confinement (requires installed unit and --systemd)'
        fi
    else
        skip 'Release-only hardening, inventory, lifecycle, QML, GUI and installed systemd checks (Release not built)'
    fi
    printf '\n===== SUMMARY =====\nPASS=%d FAIL=%d SKIPPED=%d\n' "$passes" "$failures" "$skipped"
    printf 'UTC finish: %s\n' "$(date -u +%FT%TZ)"
    if (( failures )); then echo 'OVERALL: FAIL'; return 1; fi
    if (( skipped || core_only )); then echo 'OVERALL: PARTIAL — skipped checks are not qualified'; return 0; fi
    echo 'OVERALL: PASS — automated local checks only; visual review and hosted CI remain separate'
    return 0
}
run_all 2>&1 | tee "$temp"
status=("${PIPESTATUS[@]}")
if ! finalize; then exit 2; fi
trap - EXIT
printf '\nReport: %s\n' "$report"
if (( status[1] != 0 )); then exit 2; fi
exit "${status[0]}"
