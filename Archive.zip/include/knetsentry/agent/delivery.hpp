// SPDX-FileCopyrightText: 2026 Chris Sutton
// SPDX-License-Identifier: MIT
#pragma once
#include <knetsentry/agent/journal.hpp>
#include <knetsentry/agent/normalization.hpp>
#include <knetsentry/core/enrollment.hpp>
#include <array>
#include <string>

namespace knetsentry::agent {
// Immutable destination binding, stored with the checkpoint. Not a credential.
[[nodiscard]] std::string delivery_binding(const enrollment::EndpointId& endpoint,
    const identity::Fingerprint& manager);

enum class DeliveryState { Pending, Complete, Failed };
// The trusted receiver must commit idempotently by endpoint + native cursor,
// and reject conflicting content. True means durable acceptance (including
// exact duplicates). The callback must be bounded, nonthrowing and nonreentrant.
class ReceiptSink {
public:
    virtual ~ReceiptSink() = default;
    virtual bool commit(const enrollment::EndpointId& endpoint, std::string_view binding, std::string_view canonical_row) noexcept = 0;
};

// Bounded reusable receiver-side storage, one endpoint/source per explicit
// private directory. No operational manager integration or implicit paths.
class ReceiptInbox final : public ReceiptSink {
public:
    ReceiptInbox(enrollment::EndpointId endpoint, identity::Fingerprint manager,
        JournalMode mode, std::string unit, std::string directory);
    ~ReceiptInbox() override;
    ReceiptInbox(const ReceiptInbox&) = delete;
    ReceiptInbox& operator=(const ReceiptInbox&) = delete;
    [[nodiscard]] bool start() noexcept;
    [[nodiscard]] bool commit(const enrollment::EndpointId& endpoint, std::string_view binding, std::string_view canonical_row) noexcept override;
    [[nodiscard]] std::size_t count() const noexcept { return rows_.size(); }
private:
    [[nodiscard]] bool load();
    [[nodiscard]] bool fail() noexcept;
    enrollment::EndpointId endpoint_;
    JournalMode mode_;
    std::string unit_, directory_, binding_, header_, state_;
    std::vector<std::string> rows_;
    int fd_{-1};
    bool started_{}, ready_{};
};

// M6.1: synchronous, single-owner ingestion boundary for one configured
// endpoint/source/sink. No asynchronous queue or network permission. The
// pipeline and sink must outlive all receivers; all calls are serialized.
enum class IngestOutcome { Unauthorized, Invalid, Overloaded, StorageRejected,
    TransportFailed, Abandoned, Committed, Acknowledged, Count };
class IngestionPipeline final {
public:
    static constexpr std::size_t max_inflight = 4;
    static constexpr std::size_t max_row = 2048;
    IngestionPipeline(enrollment::EndpointId endpoint, identity::Fingerprint manager,
        JournalMode mode, std::string_view unit, ReceiptSink& sink);
    IngestionPipeline(const IngestionPipeline&) = delete;
    IngestionPipeline& operator=(const IngestionPipeline&) = delete;
    [[nodiscard]] std::size_t active() const noexcept { return active_; }
    [[nodiscard]] std::uint64_t count(IngestOutcome outcome) const noexcept;
private:
    friend class DeliveryReceiver;
    [[nodiscard]] bool reserve() noexcept;
    void release() noexcept;
    void record(IngestOutcome outcome) noexcept;
    [[nodiscard]] IngestOutcome process(std::string_view payload, std::optional<NormalizedEvent>& normalized);
    enrollment::EndpointId endpoint_;
    JournalMode mode_;
    std::string unit_, binding_;
    ReceiptSink& sink_;
    std::array<std::uint64_t, static_cast<std::size_t>(IngestOutcome::Count)> counts_{};
    std::size_t active_{};
    bool configured_{};
};

// Exclusive use of a fresh established TLS session, one record per connection.
// The caller drives ciphertext, network authorization, monotonic time and
// reconnect scheduling. No socket or monitoring permission is granted here.
class DeliverySender final {
public:
    DeliverySender(JournalCollector& queue, tls::Session& session,
        const enrollment::EndpointId& endpoint, const identity::Fingerprint& manager);
    ~DeliverySender();
    DeliverySender(const DeliverySender&) = delete;
    DeliverySender& operator=(const DeliverySender&) = delete;
    [[nodiscard]] DeliveryState step(std::optional<identity::Fingerprint> current_manager,
        bool authorized, std::uint64_t now) noexcept;
private:
    JournalCollector& queue_;
    tls::Session& session_;
    std::string binding_, row_, frame_, ack_;
    std::array<unsigned char, 4096> received_{};
    std::size_t used_{};
    std::optional<std::uint64_t> start_;
    std::uint64_t last_{};
    bool sent_{}, owns_slot_{};
    DeliveryState state_{DeliveryState::Pending};
};
class DeliveryReceiver final {
public:
    DeliveryReceiver(tls::Session& session, int registry, IngestionPipeline& pipeline);
    ~DeliveryReceiver();
    DeliveryReceiver(const DeliveryReceiver&) = delete;
    DeliveryReceiver& operator=(const DeliveryReceiver&) = delete;
    [[nodiscard]] DeliveryState step(bool authorized, std::uint64_t now) noexcept;
    // Available only after durable sink acceptance; independent of ACK success.
    // Borrowed view, valid until this receiver is destroyed.
    [[nodiscard]] const std::optional<NormalizedEvent>& normalized_event() const noexcept { return normalized_; }
private:
    tls::Session& session_;
    int registry_;
    IngestionPipeline& pipeline_;
    std::optional<NormalizedEvent> normalized_;
    std::string ack_;
    bool reserved_{};
    DeliveryState finish(IngestOutcome outcome) noexcept;
    std::array<unsigned char, 4096> received_{};
    std::size_t used_{};
    std::optional<std::uint64_t> start_;
    std::uint64_t last_{};
    DeliveryState state_{DeliveryState::Pending};
};
} // namespace knetsentry::agent
