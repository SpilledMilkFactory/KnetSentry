// SPDX-FileCopyrightText: 2026 Chris Sutton
// SPDX-License-Identifier: MIT
#pragma once

#include "knetsentry/service/health.hpp"
#include "knetsentry/service/agent_roster.hpp"
#include "knetsentry/service/event_query.hpp"
#include "knetsentry/service/alert_query.hpp"

#include <array>
#include <chrono>
#include <optional>
#include <string_view>

namespace knetsentry::service {

// Client-side validation of the untrusted KSIPC/1 health payload.
[[nodiscard]] std::optional<HealthSnapshot> decode_health(
    std::string_view payload, std::string_view request_id) noexcept;

enum class HealthQueryState { Idle, Pending, Available, Unavailable, Invalid };

// One nonblocking Unix-domain exchange. No worker threads, network sockets,
// daemon discovery or general administrative operations. Call advance from an event loop.
class HealthClient final {
public:
    HealthClient() = default;
    ~HealthClient() noexcept;
    HealthClient(const HealthClient&) = delete;
    HealthClient& operator=(const HealthClient&) = delete;
    void begin(std::string_view directory, std::string_view request_id) noexcept;
    void begin_agents(std::string_view directory, std::string_view request_id) noexcept;
    void begin_events(std::string_view directory, std::string_view request_id, const EventQuery& query) noexcept;
    [[nodiscard]] const std::optional<EventPage>& events() const noexcept { return events_; }
    void begin_alerts(std::string_view directory, std::string_view request_id, const AlertQuery& query) noexcept;
    [[nodiscard]] const std::optional<AlertPage>& alerts() const noexcept { return alerts_; }
    void advance() noexcept;
    void cancel() noexcept;
    [[nodiscard]] HealthQueryState state() const noexcept { return state_; }
    [[nodiscard]] const std::optional<HealthSnapshot>& snapshot() const noexcept { return snapshot_; }
    [[nodiscard]] const std::optional<enrollment::Roster>& roster() const noexcept { return roster_; }
private:
    void begin_query(std::string_view directory, std::string_view request_id, bool agents, const EventQuery* query = nullptr, const AlertQuery* alert = nullptr) noexcept;
    void finish(HealthQueryState state) noexcept;
    [[nodiscard]] bool verify_peer() const noexcept;
    enum class Phase { Connect, Send, Receive };
    int fd_{-1};
    Phase phase_{Phase::Connect};
    HealthQueryState state_{HealthQueryState::Idle};
    std::chrono::steady_clock::time_point deadline_{};
    std::array<char, 16> request_id_{};
    std::array<char, max_event_request + 4> request_{};
    std::size_t request_size_{0};
    std::size_t sent_{0};
    // One extra byte detects oversized/trailing data without allocating.
    std::array<char, max_roster_response_size + 5> response_{};
    std::size_t received_{0};
    std::optional<HealthSnapshot> snapshot_{};
    std::optional<enrollment::Roster> roster_{};
    bool agents_{};
    bool event_request_{};
    bool alert_request_{};
    AlertQuery alert_query_;
    std::optional<AlertPage> alerts_;
    EventQuery event_query_;
    std::optional<EventPage> events_;
};

} // namespace knetsentry::service
