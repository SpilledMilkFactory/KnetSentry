<!--
SPDX-FileCopyrightText: 2026 Chris Sutton
SPDX-License-Identifier: CC-BY-SA-4.0
-->

# KnetSentry — Logical Interface and Data Contracts

> Historical baseline and design contract. For current implemented behavior and
> acceptance evidence, see [project status](../PROJECT_STATUS.md). Future requirements
> and original milestone-specific test counts below are not release claims.

**Issue:** M0.4. **State:** architecture proposals; interfaces are not yet
implemented. See [components](COMPONENT_CATALOG.md),
[system architecture](SYSTEM_ARCHITECTURE.md) and
[network requirements](../security/NETWORK_SCOPE_REQUIREMENTS.md).

## 1. Cross-interface mandatory rules

1. Every cross-process request MUST have an explicit interface version,
   message-size/collection-count limits, deadline/cancellation behavior,
   meaningful error category, and audit/metrics decision before implementation.
2. **Authentication and authenticity are different:** a valid TLS peer or Unix
   peer credential authenticates a channel principal, not the truth of an event
   field or the firmware identity of an IoT device. Preserve `SourceTrustClass`
   and evidence provenance throughout the system.
3. There are **separate authorizations** for sensor observation scope, agent
   transport, provider egress, and local operator/response permissions.
   No event, AI model, or public feed may silently create one of these grants.
4. Producer overload MUST cause bounded backpressure, explicit drop/quarantine
   accounting, or a documented failure; never unbounded allocation or silent
   fabrication of clean coverage. Replays/duplicates must use stable source-
   scoped identities and documented idempotence semantics.
5. Preserve event time, acquisition time, and receive time separately, along
   with source identity, approved scope, drop counts where measurable, and
   attribution uncertainty. A missing field remains unknown.
6. Privilege escalation and egress require independent OS enforcement, not
   only a boolean returned by a manager function. Validate actual enforcement
   after policy application; errors deny the affected operation.
7. Audit excludes raw secrets and private payloads by default. Payload/packet
   retention and incident export require separate access and retention policy.

## 2. Interface registry

The `I-##` identifiers describe **logical interface contracts**. Endpoints and
serialization are not frozen yet; implementation owners must pin encoding,
version policy and supported error codes before exposing a socket or stable ABI.

| Interface | Producer -> consumer | Essential payload and trust treatment | Authorization / failure behavior | Milestone |
| --- | --- | --- | --- | --- |
| `I-01` | Qt/CLI -> manager | `LocalRequest{version,principal,action,params,request_id}`; Unix peer credentials plus operation role | Default deny for non-authorized action; no remote admin listener | M2.3 |
| `I-02` | Manager policy -> policy applicator | `PolicyProposal{generation,approved_scope,digest,actor,evidence}` | Explicit authorized change; stage/verify/activate or rollback; never event-triggered | M3.5 |
| `I-03` | Capture broker -> sensor worker | Bounded frame data/metadata, interface/scope, original-length, truncation, loss counters | Only approved capture scope; parser unprivileged; drop accounting | M5.10 |
| `I-04` | Sensor worker -> ingest | `SourceEnvelope` with observation scope, source/clock/coverage, event shape, trust class | Approved local pipe or authenticated remote relay; reject scope violations | M5.10/M6.1 |
| `I-05` | Gateway device/export -> adapter | External syslog/flow/DHCP/DNS/AP record plus sender metadata | Approved source; sender may be spoofed; trust explicitly marked | M5.10/M9.4 |
| `I-06` | Gateway adapter -> ingest | Provenance-tagged `SourceEnvelope`, parse/confidence errors | Local channel with restricted process identity; bounded input | M5.10/M6.1 |
| `I-07` | Enrolled host agent -> receiver | Versioned authenticated telemetry and heartbeat envelope | mTLS, enrollment, revocation, scope checks, length/rate limits | M4.3–M5.5 |
| `I-08` | Receiver -> manager ingest | Verified peer fingerprint, enrollment/scopes + separately untrusted reported fields | Verify source binding, no admin commands, bounded queue | M4.3/M6.1 |
| `I-09` | Privileged host collector -> optional agent | Narrow authorized OS event records and collection health | Local authenticated IPC; minimal read permission | M5.4 |
| `I-10` | Ingest -> normalizer | `ValidatedSourceEnvelope` and declared parsing/validation status | Reject/quarantine unsupported/schema-bad records; no policy changes | M6.1/M6.2 |
| `I-11` | Normalizer -> storage | `NormalizedEvent` + `EvidenceReference` + original evidence when approved | Transactional manager-only storage write, retention, duplicate behavior | M6.2–M6.5 |
| `I-12` | Storage -> deterministic detection | Bounded event cursor and source/coverage trust metadata | Query limits; rules cannot alter original stored evidence | M7.1 |
| `I-13` | Detection -> alert/case storage | `Finding{rule_id,version,evidence_ids,uncertainty}` | Persist separately from immutable-original strategy; no response authority | M7.6/M11.1 |
| `I-14` | Ingest/storage -> asset/coverage intelligence | Asset observations, scoped device hints, drop/capability state | Tentative ID and confidence; IP/MAC alone never verified identity | M9.1/M9.2 |
| `I-15` | Manager -> feed worker | `ApprovedFeedRequest{provider_id,feed_id,policy_generation}`; no arbitrary event URL | Provider opt-in and allowed operations; default deny, audit query privacy | M3.9/M10.9 |
| `I-16` | Feed worker -> approved public provider | Bounded TLS HTTPS request, only approved endpoint/path/redirect policy | DNS/connected-peer checks, TLS validation, host firewall egress | M3.9/M10.9 |
| `I-17` | Feed worker -> manager | Bounded feed bytes + origin/version/freshness metadata, no direct DB writes | Untrusted parser, provenance checks, quarantine and atomic cache promotion | M10.9 |
| `I-18` | Manager -> isolated AI worker | Minimized, pre-authorized evidence context + bounded result | No network, file access or tools beyond approved IPC; timeout/fail independently | M12.2–M12.9 |
| `I-19` | Incident gate -> policy applicator | `ApprovedResponse{actor,scope,action,expiry,audit_ref}` | Disabled by default, explicit human approval, narrow operation; verify outcome | M11.5 |
| `I-20` | Case service -> authorized export | Incident evidence references, redaction/export policy, audit record | Role-checked, safe output destination, review before disclosure | M11.6 |
| `I-21` | Components -> audit/health | Category-coded operation outcome, backlog/drops, no secrets | Privilege-aware redaction and bounded retention; fail/report audit gaps | M1.6/M2.5 |
| `I-22` | Remote authorized sensor -> receiver | Sensor-scoped signed/mTLS identity + approved sensor events | Separate enrollment profile from host agents, bounded and scope-bound | M4/M5.10 |
| `I-23` | Manager authorized query -> Qt C++ models/QML | Typed paginated `Asset/Event/Alert/Case` read models and state updates | `I-01` authorization; no direct DB/privileged operations | M1.4/M6.8/M8 |

## 3. Source evidence envelope: semantic sketch

```text
SourceEnvelope v1 (logical fields, NOT a wire encoding)
  source_id: stable configured source identifier
  source_kind: passive_capture | gateway_export | host_agent | remote_sensor
  transport_identity: authenticated principal OR unauthenticated/unknown
  observation_scope_id: approved scope reference
  observed_local_asset: optional tentative identifier and evidence
  observed_remote_peer: optional untrusted network endpoint
  source_event_id: optional source-local deduplication key
  source_event_time: optional with declared clock/uncertainty
  acquisition_time: when collector acquired available record
  manager_receive_time: set by manager on receipt, never trusted from source
  source_trust_class: cryptographically_authenticated | configured_but_unverified | unknown
  attribution_confidence: unknown | low | medium | high (not proof)
  coverage: observed | partial | unavailable | unknown + drop counters when measurable
  data_classification: metadata | allowed_raw_event | allowed_packet_payload
  evidence_data: bounded source bytes / typed fields under approved collection policy
  schema_version / content_type / limits / validation_result
```

This is a required information model, not an instruction to retain private
packet payloads. `cryptographically_authenticated` authenticates the submitting
principal only. External IPs in source evidence must never become implicit
requests to `I-16`. Untrusted event text may contain hyperlinks, shell code,
model instructions, credential strings, and fake timestamps: all remain data.

**Disposition:** `accepted`, `rejected`, `quarantined` or `degraded` with a
reason (e.g. `scope_denied`, `oversize`, `unsupported_version`,
`source_unverified`, `queue_full`, `parse_error`). Exact enum names and
limits will be finalized with versioned protocol schemas in M4–M6.

### Raw-storage and index-storage stage semantics

Interface `I-11` is subject to the
[storage placement contract](STORAGE_PLACEMENT_CONTRACT.md): authorized raw
original records commit to the administrator-selected raw local volume before
normalization/indexing. The manager separately records `RAW_DURABLE`,
`INDEX_PENDING` and `INDEXED`. The unprivileged GUI may select a candidate
folder but cannot grant write authority; the manager validates mount identity,
permissions and space before accepting it. Missing/replaced mounts are denied
without implicit OS-drive fallback. SQLite/index paths are independently
configured and must support reliable local locking and WAL semantics.

## 4. Failures and recovery by boundary

| Failure | Mandatory architectural response |
| --- | --- |
| Unknown local network source | Do not grant management authority; ingest only if policy permits passive/source observation, with reduced trust or rejection |
| Sensor lacks network visibility | Report unavailable/partial coverage; never show "all devices safe" |
| Invalid agent certificate or scope | Reject session before accepting trusted telemetry; preserve bounded security audit |
| Unexpected route or firewall divergence | Deny affected connection/operation until policy is independently verified |
| Unsupported event type or out-of-budget payload | Reject/quarantine; count and expose losses; avoid crashes or unlimited retries |
| Storage unavailable or full | Bounded buffer/retention, prominent degraded state, documented recovery; no fictitious events |
| Approved feed down or invalid | Keep last validated cache with staleness visible; core SIEM continues |
| AI model missing or unsafe | Disable/degrade AI only; deterministic detection and cases unaffected |
| Operator or response unauthorized | Reject and audit; do not accept rule/AI/feed text as operator approval |
| Capture broker crashes | Sensor marks source unavailable; restarts only through approved service policy; no silent scope expansion |

## 5. Implementation and compatibility governance

The initial ABI/wire protocol, file formats, max sizes, TLS stack, mTLS
certificate profile, migration strategy, IPC socket paths, OS sandbox profile
and error catalog are **open** until their owning milestone implements and
tests them. Version negotiation and compatibility behavior must be explicit,
never implicit fallback to an insecure or unvalidated mode.

Any interface revision crossing `TB-01`–`TB-12` requires reviewing the threat
register and its verification matrix, with an explicit regression test owner.

## M4.1 wire contract (I-07)

[KSAP 1.0](../development/AGENT_PROTOCOL_M41.md) specifies an offline bounded
HELLO/HEARTBEAT encoding and connection-local sequencing. It does not implement
the operational authenticated channel, source binding, enrollment or telemetry
envelope. Those requirements and the I-08 provenance boundary remain in force.

M4.2 defines the offline [identity contract](../development/IDENTITY_M42.md)
for I-07/I-08: role-bound certificate validation against an explicit trust
anchor and independently approved public-key fingerprint. This does not
establish proof of possession, enrollment, revocation or network authority.

M4.3 implements [mutual TLS](../development/TLS_TRANSPORT_M43.md) for I-07/I-08
with bounded in-memory ciphertext endpoints, explicit role/pin checks and
proof of key possession. No operational network adapter, enrollment authority,
revocation or ingestion authorization is introduced.

M4.4 adds [explicit endpoint enrollment](../development/ENDPOINT_ENROLLMENT_M44.md)
for I-07/I-08: a local administrative ID-to-pin registry and admission check
against a currently trusted manager-side TLS session. No peer can approve itself.
Operational adapter, RBAC, revocation and ingestion authorization remain pending.

M4.5 adds [credential lifecycle](../development/CREDENTIAL_LIFECYCLE_M45.md)
for explicit new-key rotation, permanent revocation, current certificate
validity and terminal revalidation. Future operational adapters must use the
current approved identity and revalidate before application processing.

M4.6 adds [authenticated agent health](../development/AGENT_HEALTH_M46.md) for
I-07/I-08: KSAP framing over current TLS/enrollment, explicit missing/degraded
state and reconnect scheduling. No operational ingestion authority is granted.

## M4.7 read-only agent roster (I-01 / I-23)

[Desktop enrollment management](../development/DESKTOP_AGENT_MANAGEMENT_M47.md)
publishes a bounded pin-free registry snapshot through authenticated local IPC.
No operational agent session or administrative mutation interface is exposed.

### M7.1 development boundary

[I-12 development engine](../development/DETECTION_ENGINE_M71.md) consumes one minimized EventSummary from a bounded caller-selected page and explicit caller-provided trust and coverage metadata. Findings reference a store-scoped ID and rule revision; neither the engine nor its output grants I-13 persistence or response authority.

### M7.2 rule configuration boundary

The [versioned rule schema](../development/RULE_SCHEMA_M72.md) requires validated metadata, supported source requirements and reachable predicates before constructing a schema-aware engine. Static diagnostics do not echo supplied content. The trusted caller retains ownership of authorization, rule history and store provenance. No operational scheduling or response authority is introduced.

### M7.3 authentication pattern boundary

The [authentication pattern scan](../development/AUTHENTICATION_PATTERNS_M73.md) consumes a revision-bound, exact-binding and exact-source EventStore snapshot under explicit caller-established trust. It uses schema-validated predicates, bounded receiver-time windows and store-scoped evidence IDs. It does not establish account identity, authorize access, or persist alerts.

### M7.4 system integrity boundary

The [Audit detection scan](../development/SYSTEM_INTEGRITY_M74.md) uses policy-approved numeric record types projected from validated stored evidence, exact endpoint scope and a revision-bound snapshot. It emits bounded evidence-linked findings without inferring operation outcome, expanding OCSF mappings, changing GUI IPC, or granting operational authority.

### M7.5 scheduling boundary

The [scheduler](../development/RULE_SCHEDULING_M75.md) composes the validated M7.2 engine with bounded exact-scope stored snapshots and a private state checkpoint. A durable pending generation is replayed until the caller acknowledges it. Scheduling does not confer store authorization, alert publication, response authority or live monitoring.

### M7.6 alert lifecycle boundary

The [alert ledger](../development/ALERT_LIFECYCLE_M76.md) consumes only a committed scheduler generation and revalidates durable evidence before atomic publication. Stable keys and revisions separate analyst lifecycle changes from original evidence. Caller authorization, serial access, volume identity and operational integration remain outstanding.

### M7.7 local alert interface (I-01 / I-13)

See [M7.7](../development/ALERT_INTERFACE_M77.md). Explicitly opted-in same-UID/GID manager mediates bounded alert listing, exact evidence lookup and optional revision-checked acknowledgement. Actor and clock are manager-derived; persistent audit is required. Default denies access, read mode denies acknowledgement. No production RBAC, direct GUI ledger access or response authority.
